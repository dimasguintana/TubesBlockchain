//init express app
var app = require('express')();

//init express server
var http = require('http').createServer(app);

//init socket.io listening ke express server
var io = require('socket.io')(http);

//init crypto-js SHA256
const SHA256 = require('crypto-js/sha256');

const CryptoJS = require('crypto-js');

var express = require("express");

app.use(express.static('public'));

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/index.html');
});

function generateSalt(index) {
	//bikin sebuah pola
	var pattern = Math.pow(Math.acos(Math.log(Math.pow((13579*index),24680))), Math.sin(987654312345*index*2343223144/123123342)*Math.acos(2131321*index*index*index*675432454754));
	
	//ubah pattern menjadi string
	var string_pattern = pattern.toString();
	
	//hash string_pattern
    var hash_pattern = SHA256(string_pattern).toString();
    return hash_pattern;
};

var index = 0;
var previous_hash = 'Genesis Hash';

io.on('connection', function(socket) {
    console.log('user connected');
    socket.on('chat message', function(data) {

        //increment index
        index++;

        //bikin timestamp
        var date = new Date();
        var timestamp = date.toUTCString();

        //generate salt
        var salt = generateSalt(index);

        //bikin nonce
        var nonce = SHA256(data + salt).toString();

        //bikin hash
        var hash = SHA256(index.toString() + data + "&(*^&#$%^&)(*&^%$#@!@#$%^&*(asoidacnipwpecpabscasc][\]}{}{}|}.,//.," + timestamp + nonce + previous_hash).toString();

        var block = {
            'index' : index,
            'data' : data,
            'timestamp' : timestamp,
            'nonce' : nonce,
            'hash' : hash,
            'previous_hash' : previous_hash
        };

        //enkripsi
        var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(block), 'kunci rahasia').toString();

        console.log(data);
        console.log('data input: ', ciphertext);
        io.emit('clientEvent', ciphertext);
        previous_hash = hash;

    });
});

http.listen(1010, function(){
    console.log('listening on 1010');
  });