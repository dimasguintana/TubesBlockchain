//init socket.io-client
var io = require('socket.io-client');

//init listening socket
var socket = io.connect('http://localhost:1010');

const CryptoJS = require('crypto-js');

const BlockChain = require('./Blockchain.js');
const Block = require('./Block.js');

//initialize model
const blockchain = new BlockChain();

socket.on('connect', function() { 
    console.log('connected to server');
    socket.on('clientEvent', function (data) {

        //dekripsi
        var bytes = CryptoJS.AES.decrypt(data, 'kunci rahasia');
        var decryptData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));

        var block = new Block(decryptData.index, decryptData.data, decryptData.timestamp, decryptData.nonce, decryptData.hash, decryptData.previous_hash);
        var previous_block = blockchain.getNewestBlockFromBlockchain();

        if (block.validateBlock(block, previous_block) != 0) {
            console.log('Error code : ' + block.validateBlock(block, previous_block));
        } else {
            blockchain.addBlock(block);
            blockchain.showLatestBlock();
        }
    }); 
});